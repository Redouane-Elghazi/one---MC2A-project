#ifndef TOOLBOX_HPP_INCLUDED
#define TOOLBOX_HPP_INCLUDED

int sgn(double x);

#endif // TOOLBOX_HPP_INCLUDED
